/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author PCentorno Junit pruebas Unitarias
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class p4ju {
    @Test
    public void testSum() {
        MiClase clase = new MiClase();
        int resultado = clase.sumar(2, 3);
        assertEquals(5, resultado);
    }

    private static class MiClase {
        public MiClase() {
        }

        public int sumar(int a, int b) {
            return a + b;
        }
    }
}
