/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author PCentorno para jmeter pruebas Rendimiento y Carga
 */
public class p44rc {
    public static void main(String[] args) throws Exception {
        // Cambia la ruta a la ubicación de tu archivo .jmx
        String jmxFilePath = "C:\\Users\\PC\\Documents\\NetBeansProjects\\pruebas.jmx";

        ProcessBuilder builder = new ProcessBuilder("jmeter", "-n", "-t", jmxFilePath);
        builder.start();
    }
}
