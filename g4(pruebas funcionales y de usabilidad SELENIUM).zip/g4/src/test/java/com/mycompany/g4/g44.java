/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.g4;

/**
 *
 * @author PCentorno selenium pruebas Funcionales y de Usabilidad
 */
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;

public class g44 {
    @Test
    public void testLoginRedirection() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\PC\\Downloads\\chrome-win64\\chrome-win64\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        
        driver.get("http://localhost:8080/miApp");
        driver.findElement(By.id("loginButton")).click();
        
        // Verificar que el usuario fue redirigido
        String urlActual = driver.getCurrentUrl();
        assertEquals("http://localhost:8080/dashboard", urlActual);
        
        driver.quit();
    }
}
